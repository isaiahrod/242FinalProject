package view;

import java.util.EventListener;

public interface LoginListener extends EventListener {

	public void okButtonClick(OKButtonEventObject ev);
}
