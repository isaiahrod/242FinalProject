package controller;

import javafx.stage.Stage;
import model.BagOfBags;
import model.Staff;
import model.Student;
import view.CurriculumWindow;
import view.LoginListener;
import view.LoginWindow;
import view.OKButtonEventObject;
import view.SainReportWindow;
import view.SainShortWindow;

public class Controller {

	Student stu;
	Staff sta;
	CurriculumWindow curriculumWindow;

	public Controller(LoginWindow window, BagOfBags bag) {
		window.setLoginListener(new LoginListener() {

			@Override
			public void okButtonClick(OKButtonEventObject ev) {

				if ((ev.getPassword()).equals(bag.getStudentBag().findByUser((ev.getUsername())).getPass())) {
					stu = bag.getStudentBag().findByUser(ev.getUsername());
					curriculumWindow = new CurriculumWindow(window.getStage());

					curriculumWindow.setProgramTerm("Spring 2016");
					curriculumWindow.setCatalogTerm("Spring 2016");
					curriculumWindow.setLevel("Undergraduate");
					curriculumWindow.setCampus("Ammerman");
					if (stu.getMajorId().equals("CST")) {
						curriculumWindow.setCollege("Computer Science");
					} else if (stu.getMajorId().equals("BIS")) {
						curriculumWindow.setCollege("Business");
					}
					curriculumWindow.setDegree("Associate");
					if (stu.getMajorId().equals("CST")) {
						curriculumWindow.setFirstMajor("Computer Science");
					} else if (stu.getMajorId().equals("BIS")) {
						curriculumWindow.setFirstMajor("Business");
					}
					curriculumWindow.getReportButton().setOnAction(action -> {
						SainShortWindow sainShortWindow = new SainShortWindow(curriculumWindow.getStage());
						if (stu.getMajorId().equals("CST")) {
							sainShortWindow.setProgramField("Computer Science - AS");
						} else if (stu.getMajorId().equals("BIS")) {
							sainShortWindow.setProgramField(("Business - AS"));
						}
						sainShortWindow.setDegreeField("Associate in Science");
						if (stu.getMajorId().equals("CST")) {
							sainShortWindow.setMajorField("Computer Science");
						} else if (stu.getMajorId().equals("BIS")) {
							sainShortWindow.setMajorField(("Business"));
						}
						sainShortWindow.getGeneratorButton().setOnAction(action2 -> {
							if ((sainShortWindow.getSelector()).getValue().toString().equals("Fall 2015")
									|| sainShortWindow.getSelector().getValue().toString().equals("Spring 2016")
									|| sainShortWindow.getSelector().toString().equals("Summer 2016")
									|| sainShortWindow.getSelector().toString().equals("Fall 2016")) {
								// all terms do the same thing
								SainReportWindow srWindow = new SainReportWindow(sainShortWindow.getStage());

								if (stu.getMajorId().equals("CST")) {
									srWindow.getProgramField().setText(("Computer Science - AS"));
								} else if (stu.getMajorId().equals("BIS")) {
									srWindow.getProgramField().setText(("Business - AS"));
								}
								if (stu.getMajorId().equals("CST")) {
									srWindow.getMajorField().setText(("Computer Science"));
								} else if (stu.getMajorId().equals("BIS")) {
									srWindow.getMajorField().setText(("Business"));
								}
								srWindow.getDegreeField().setText("Associate in Science");
								srWindow.getCumGpaField().setText(String.valueOf((stu.getGpa())));
								srWindow.getProgGpaField().setText(String.valueOf((stu.getGpa())));
								srWindow.getMajorGpaField().setText(String.valueOf(String.valueOf((stu.getGpa()))));
								srWindow.getCampusField().setText("Ammerman");
								srWindow.getEnteredField().setText("Fall 2014");
								srWindow.getMetriculatedField().setText("Spring 2015");
								srWindow.getCatalogField().setText("Spring 2016");
								srWindow.getEvalTermField().setText("Spring 2016");
								srWindow.getPriorDegreesField().setText("None");
								if (stu.getCoursesTaken() == null) {
									srWindow.getCoursesTakenArea().setText("None");
								} else {
									srWindow.getCoursesTakenArea().setText(stu.getCoursesTaken().toString());
								}
								if (stu.getCoursesOther() == null) {
									srWindow.getOtherCoursesTakenArea().setText("None");
								} else {
									srWindow.getOtherCoursesTakenArea().setText(stu.getCoursesOther().toString());
								}
								if (stu.getCoursesFailed() == null) {
									srWindow.getCoursesWithdrawnArea().setText("None");
								} else {
									srWindow.getCoursesWithdrawnArea().setText(stu.getCoursesFailed().toString());
								}
								if (stu.getCoursesTaking() == null) {
									srWindow.getCurrentCoursesArea().setText("None");
								} else {
									srWindow.getCurrentCoursesArea().setText(stu.getCoursesTaking().toString());
								}
								srWindow.getCloseButton().setOnAction(action3 -> {
									bag.saveStaff("staff.dat");
									bag.saveStudents("students.dat");
									srWindow.getStage().close();
								});
							}
						});
					});
				} else if (ev.getPassword() == "" || ev.getUsername() == "") {
					window.setUsernameField("Please Enter User/Password");
					window.setPwField("");
				} else {
					window.setUsernameField("Incorrect User/Password");
					window.setPwField("");
				}
			}

		});

	}
}
