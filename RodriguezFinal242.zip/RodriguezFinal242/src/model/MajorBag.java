package model;

import java.util.ArrayList;

public class MajorBag {

	ArrayList<Major> majors;
	
	public MajorBag(ArrayList<Major> majors) {
		super();
		this.majors = majors;
	}

	public Major findMajorByID(int id){
		return null;
	}
	
	public void addMajor(Major m){
		majors.add(m);
	}
	
	
}
