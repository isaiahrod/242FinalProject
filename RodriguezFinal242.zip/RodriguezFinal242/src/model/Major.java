package model;

import java.util.ArrayList;

public class Major {

	String title;
	String id;
	int totalCredits;
	ArrayList<Course> coursesReq;
	ArrayList<Course> englighCourseReq;
	ArrayList<Course> ssCourseReq;
	ArrayList<Course> pedCourseReq;
	ArrayList<Course> humCourseReq;
	ArrayList<Course> mathCourseReq;




}
