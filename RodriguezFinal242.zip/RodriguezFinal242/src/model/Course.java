package model;

public class Course {

	String title;
	int creditsWorth;
	String courseNum;
	String grade;

	public Course(String title, int creditsWorth, String courseNum, String grade) {
		super();
		this.title = title;
		this.creditsWorth = creditsWorth;
		this.courseNum = courseNum;
		this.grade = grade;
	}

	@Override
	public String toString() {
		return "Course [title=" + title + ", creditsWorth=" + creditsWorth + ", courseNum=" + courseNum + ", grade="
				+ grade + "]";
	}

}
