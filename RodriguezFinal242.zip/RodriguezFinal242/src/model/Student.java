package model;

import java.io.Serializable;
import java.util.ArrayList;

public class Student implements Serializable {

	int id;
	String name;
	String username;
	private String password;
	double gpa;
	ArrayList<Course> coursesTaken;
	ArrayList<Course> coursesOther;
	ArrayList<Course> coursesFailed;
	ArrayList<Course> coursesTaking;
	String majorId;

	public Student(String name, String pass, int id, String majorID, double gpa) {
		this.name = name;
		this.id = id;
		this.password = pass;
		String[] firstLast = name.split(" ");
		this.username = firstLast[1] + Integer.toString(this.id);
		this.majorId = majorID;
		this.gpa = gpa;
		this.coursesTaken = null;
		this.coursesOther = null;
		this.coursesFailed = null;
		this.coursesTaking = null;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPass() {
		return this.password;
	}

	public String getUsername() {
		return this.username;
	}

	public double getGpa() {
		return gpa;
	}

	public void setGpa(double gpa) {
		this.gpa = gpa;
	}

	public ArrayList<Course> getCoursesTaken() {
		return coursesTaken;
	}

	public void setCoursesTaken(ArrayList<Course> coursesTaken) {
		this.coursesTaken = coursesTaken;
	}

	public ArrayList<Course> getCoursesOther() {
		return coursesOther;
	}

	public void setCoursesOther(ArrayList<Course> coursesOther) {
		this.coursesOther = coursesOther;
	}

	public ArrayList<Course> getCoursesFailed() {
		return coursesFailed;
	}

	public void setCoursesFailed(ArrayList<Course> coursesFailed) {
		this.coursesFailed = coursesFailed;
	}

	public ArrayList<Course> getCoursesTaking() {
		return coursesTaking;
	}

	public void setCoursesTaking(ArrayList<Course> coursesTaking) {
		this.coursesTaking = coursesTaking;
	}

	public String getMajorId() {
		return majorId;
	}

	public void setMajorId(String majorId) {
		this.majorId = majorId;
	}

	public void setUsername(String user) {
		this.username = user;
	}

	public void setPass(String pass) {
		this.password = pass;
	}

}
