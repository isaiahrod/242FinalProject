package demos;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import controller.Controller;
import javafx.application.Application;
import javafx.stage.Stage;
import model.BagOfBags;
import model.Staff;
import model.StaffBag;
import model.Student;
import model.StudentBag;
import view.LoginWindow;

public class Demo2 extends Application {

	StudentBag studentBag = new StudentBag(5);
	StaffBag staffBag = new StaffBag(5);

	BagOfBags bag = new BagOfBags(staffBag, studentBag);

	public static void main(String[] args) {

		launch(args);
	}

	@Override
	public void start(Stage stage) throws Exception {

		// bag.getStudentBag().add(new Student("John Doe", "pass", 1, "CST",
		// 3.4));
		// bag.getStudentBag().add(new Student("Mary Jane", "password", 2,
		// "BIS", 3.5));
		// bag.getStaffBag().add(new Staff("Teacher Teacher", "pw", 3));
		// bag.getStaffBag().add(new Staff("Teacher Professor", "pw+", 4));
		
		//kept all this here to remember passwords for login

		bag.readStaff("staff.dat");
		bag.readStudents("students.dat");

		LoginWindow window = new LoginWindow(stage);
		Controller controller = new Controller(window, bag);

	}

}
